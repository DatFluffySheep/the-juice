function setup() {
  createCanvas(128, 128);
}

function draw() {
  background(51);
  strokeWeight(4);
  stroke(255);
  point(30, 100);
  point(86, 86);
  point(50, 47);
  rect(20, 20, 20, 20);
  strokeWeight(2);
  strokeCap(ROUND);
  line(32, 100, 84, 86);
  line(84, 86, 50, 49);
  ellipse(90, 20, 20, 20);
  noStroke();
  fill(100)
  ellipse(90, 20, 15, 15);
}