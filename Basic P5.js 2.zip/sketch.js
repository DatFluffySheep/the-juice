function setup() {
  createCanvas(128, 128);
}

function draw() {
  background(1)
  fill(0,255,255);
  colorMode(RGB, 255, 255, 255, 1);
  
  strokeWeight(4);
  stroke(255, 255, 255, 0.5);
  ellipse(40, 40, 40, 40);
  
  stroke(0, 150, 255, 0.5);
  fill(255, 0 ,255);
  ellipse(50, 80, 30, 30);
  
  stroke(1, 1, 1, 0.0);
  fill(255, 255 ,0 , 0.5);
  ellipse(50, 80, 60, 20);
  
  stroke(1, 1, 1, 0.0);
  fill(255, 255 ,0);
  triangle(120, 60, 90, 30, 120, 30);
  
  stroke(255, 1, 1, 0.2);
  fill(255, 255 ,0, 0.3);
  quad(90, 90, 120, 60, 126, 40, 88, 22)
  
  noFill();
  noFill();
  stroke(255, 0, 0, 0.2);
  curve(90, 90, 60, 90, 126, 40, 120, 30)
  stroke(0);
}