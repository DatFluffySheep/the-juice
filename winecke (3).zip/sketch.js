// initialize variables
let mx = 0;
let my = 0;
let px = 0;
let py = 0;
let fr = 0;
let time = 1;

function setup() {

	createCanvas(400, 400);
    background(1);

	strokeWeight(1);
	stroke(0, 20);

	let fr = 30;
	frameRate(fr);

}

function draw() {

// set new frame rate based on a math function
	let fr = sqrt(144);
	frameRate(fr);

// show output of variable fr value, used for frameRate in console

	print(fr);

// set variables to updated values based on current and previous mouse position
	let mx = mouseX;
	let my = mouseY;
	let px = pmouseX;
	let py = pmouseY;

// set variable to distance between current and previous mouse position
	var weight = dist(mx, my, px, py);
    
    print(weight);
    
	colorMode(RGB, 255, 255, 255, 1);

// update stroke value to distance between mouse positions
	strokeWeight (weight);

// set a color and alpha vaue for the stroke
  //color based off of mouse movement
    if(weight < 30)
	stroke(200, 50, 75, 0.75);
  
    if(weight >= 30 && weight < 60)
    stroke(50, 200, 75, 0.75);
  
    if(weight >= 60)
    stroke(50, 75, 200, 0.75);
// create a line with the stroke value based on the current and previous mouse positions
	line(mx, my, px, py);
    time +=1;
    print("Iterated this many times: ", time);
}